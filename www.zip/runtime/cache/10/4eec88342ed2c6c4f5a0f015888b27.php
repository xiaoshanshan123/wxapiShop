<?php
//000000007200a:4:{s:11:"session_key";s:24:"C9axYIS8I6PPnXZvduSbGw==";s:6:"openid";s:28:"owrkU0WQRdCzUhjkwt0cwQeXvpkM";s:3:"uid";i:3;s:5:"scope";i:16;}
?>