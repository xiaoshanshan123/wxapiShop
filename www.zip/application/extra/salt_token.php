<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/1/28
 * Time: 15:07
 */
return [

    'token' => 'lskdafsdlkfjdslkjf55SDFJKGKJLH'
];