<?php

//  +---------------------------------
//  微信相关配置
//  +---------------------------------

return [
			        // 小程序app_id
					'app_id'=>'wx50ab34067d65a148',
				    // 小程序app_secret
					'secret'=>'319cbff6f72da7378cd29cdf9bcbe14a',
		    		// 微信使用code换取用户openid及session_key的url地址
					'login_url'=>'https://api.weixin.qq.com/sns/jscode2session?appid=%s&secret=%s&js_code=%s&grant_type=authorization_code'
		];