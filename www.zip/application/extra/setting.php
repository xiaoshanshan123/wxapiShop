<?php
/**
 * 基本配置
 * config调用
 */
return [
	'img_pre' => 'kk.cn/images'
];