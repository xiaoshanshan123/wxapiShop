<?php
/**
 * Created by 七月.
 * Author: 七月
 * Date: 2017/4/12
 * Time: 5:02
 */

phpinfo();