<?php

namespace app\api\model;

use think\Model;

class User extends BaseModel
{

	protected $hidden = [];
    //一对一的关系 
	
		


}
