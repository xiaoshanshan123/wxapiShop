<?php

	return [
			'app_id'=>'',
			'secret'=>'',
			'requst_url'=>'https://api.weixin.qq.com/sns/jscode2session?appid=APPID&secret=SECRET&js_code=JSCODE&grant_type=authorization_code'
];